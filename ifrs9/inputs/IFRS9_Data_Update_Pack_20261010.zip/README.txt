IFRS 9 BANKING STUDY — DATA UPDATE, 10 OCTOBER 2026

This pack accompanies IFRS9_Master_Data_Updated_20261010.xlsx and the data-update note.
selected_data.csv: 47 selected bank-years, 11 banks, 25 pre-2018 and 22 post-2018.
New primary records: UBA 2015 and 2016, using the 2016 report's Bank columns.
The other 45 selected observations inherit earlier source decisions, not fresh verification.
All monetary amounts are NGN millions; ratios are percentage points.
Missing values are blank, not zero. Reporting-version and scope exceptions remain recorded.

recompute.py uses only Python's standard library. Run python recompute.py.
It recomputes 16 metrics per observation and compares the results with the saved values.
It does not verify sources, invent missing figures, or estimate regressions.

New_Primary_Evidence.csv contains 41 page-checked values.
current_uploads/*.json preserves the parsed current tables and source qualifications.
prior_evidence/ contains unchanged lineage/source/exception files from the previous pack.
These records are not additional independent observations, and may contain duplicates and alternatives.

The attached full thesis and its twelve graphs were not overwritten in this data release.
The newly supplied FINAL manuscript provides summary statistics, not the claimed 130-row panel.
The current repeated CSV and Word tables do not add any changed raw financial/indicator fields.

The complete annual-report PDFs are NOT bundled; source URLs and page locators are supplied.
