#!/usr/bin/env python3
"""Reproduce derived ratios from the selected IFRS 9 CSV using Python's standard library.
This script checks arithmetic; it does not verify annual-report sources or impute missing values.
Run: python recompute.py
Optional: python recompute.py --input selected_data.csv --output recalculated.csv
"""
from __future__ import annotations
import argparse, csv, json, math
from pathlib import Path

FIELDS = ["average_assets","roa","eqta","ocf_ratio","allr","car_computed",
          "impairment_assets","broad_coverage","npl_calc","stage3_ratio","stage3_coverage",
          "roa_closing","leverage","ln_assets","balance_residual","loan_residual"]

def number(value: str | None) -> float | None:
    if value is None or str(value).strip() in ("", "None", "NA", "N/A"):
        return None
    value = str(value).replace(",", "").replace("−", "-").strip()
    if value.startswith("(") and value.endswith(")"):
        return -abs(float(value[1:-1]))
    result = float(value)
    if not math.isfinite(result):
        raise ValueError(f"Non-finite numeric input: {value}")
    return result

def ratio(n: float | None, d: float | None) -> float | None:
    return 100*n/d if n is not None and d is not None and d > 0 else None

def calculate(row: dict[str, str]) -> dict[str, float | None]:
    n = lambda f: number(row.get(f))
    a, o, e, l, p, cf = (n(k) for k in
        ("assets", "opening_assets", "equity", "liabilities", "pat", "ocf"))
    gl, al, nl = (n(k) for k in ("gross_loans", "loan_allowance", "net_loans"))
    avg = (a+o)/2 if a is not None and o is not None and a > 0 and o > 0 else None
    return {
        "average_assets": avg, "roa": ratio(p, avg), "eqta": ratio(e, a),
        "ocf_ratio": ratio(cf, avg), "allr": ratio(al, gl),
        "car_computed": ratio(n("regulatory_capital"), n("rwa")),
        "impairment_assets": ratio(n("total_impairment"), avg),
        "broad_coverage": ratio(al, n("npl_amount")),
        "npl_calc": ratio(n("npl_amount"), gl),
        "stage3_ratio": ratio(n("stage3_gross"), gl),
        "stage3_coverage": ratio(n("stage3_allowance"), n("stage3_gross")),
        "roa_closing": ratio(p, a), "leverage": ratio(l, a),
        "ln_assets": math.log(a) if a is not None and a > 0 else None,
        "balance_residual": a-l-e if None not in (a,l,e) else None,
        "loan_residual": gl-al-nl if None not in (gl,al,nl) else None
    }

def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=Path(__file__).with_name("selected_data.csv"))
    parser.add_argument("--output", type=Path, default=Path(__file__).with_name("recalculated.csv"))
    args = parser.parse_args()
    if not args.input.is_file():
        parser.error(f"Input file not found: {args.input}")
    with args.input.open(encoding="utf-8-sig", newline="") as f:
        reader=csv.DictReader(f); fieldnames=reader.fieldnames or []; rows=list(reader)
    keys=[(r["bank"], int(r["year"])) for r in rows]
    if len(set(keys)) != len(keys):
        raise ValueError("Duplicate bank-year keys must be resolved before recalculation.")
    changes=[]; count=0
    for row in rows:
        values=calculate(row)
        for f,new in values.items():
            old=number(row.get(f)); count += 1
            same=(new is None and old is None) or (
                new is not None and old is not None and math.isclose(new,old,rel_tol=1e-10,abs_tol=1e-7))
            if not same:
                changes.append({"bank":row["bank"],"year":row["year"],"field":f,"old":old,"new":new})
            row[f]="" if new is None else new
    fieldnames += [f for f in FIELDS if f not in fieldnames]
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with args.output.open("w", encoding="utf-8-sig", newline="") as f:
        w=csv.DictWriter(f, fieldnames=fieldnames);w.writeheader();w.writerows(rows)
    summary={"rows":len(rows),"banks":len({k[0] for k in keys}),
             "pre_2018":sum(y<2018 for _,y in keys),"post_2018":sum(y>=2018 for _,y in keys),
             "metric_checks":count,"differences":changes}
    args.output.with_suffix(".json").write_text(json.dumps(summary,indent=2),encoding="utf-8")
    print(json.dumps(summary,indent=2))
    if changes:
        raise SystemExit("Recalculation differences were recorded; inspect before using the output.")

if __name__ == "__main__":
    main()
